export const environment = {
    api: 'http://localhost:8000/api'
};

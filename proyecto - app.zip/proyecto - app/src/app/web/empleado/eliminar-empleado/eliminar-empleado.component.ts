import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-empleado',
  imports: [],
  templateUrl: './eliminar-empleado.component.html',
  styleUrl: './eliminar-empleado.component.css'
})
export class EliminarEmpleadoComponent {

}

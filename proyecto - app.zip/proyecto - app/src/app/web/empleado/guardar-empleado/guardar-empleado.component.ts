import { Component } from '@angular/core';

@Component({
  selector: 'app-guardar-empleado',
  imports: [],
  templateUrl: './guardar-empleado.component.html',
  styleUrl: './guardar-empleado.component.css'
})
export class GuardarEmpleadoComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-empleado',
  imports: [],
  templateUrl: './listar-empleado.component.html',
  styleUrl: './listar-empleado.component.css'
})
export class ListarEmpleadoComponent {

}

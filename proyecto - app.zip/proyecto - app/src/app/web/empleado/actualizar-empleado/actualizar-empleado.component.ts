import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-empleado',
  imports: [],
  templateUrl: './actualizar-empleado.component.html',
  styleUrl: './actualizar-empleado.component.css'
})
export class ActualizarEmpleadoComponent {

}

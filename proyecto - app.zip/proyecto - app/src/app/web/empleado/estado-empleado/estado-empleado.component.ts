import { Component } from '@angular/core';

@Component({
  selector: 'app-estado-empleado',
  imports: [],
  templateUrl: './estado-empleado.component.html',
  styleUrl: './estado-empleado.component.css'
})
export class EstadoEmpleadoComponent {

}

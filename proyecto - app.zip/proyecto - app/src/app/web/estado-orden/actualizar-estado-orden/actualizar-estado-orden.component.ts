import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-estado-orden',
  imports: [],
  templateUrl: './actualizar-estado-orden.component.html',
  styleUrl: './actualizar-estado-orden.component.css'
})
export class ActualizarEstadoOrdenComponent {

}

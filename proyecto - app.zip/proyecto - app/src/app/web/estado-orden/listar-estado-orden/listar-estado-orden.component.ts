import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-estado-orden',
  imports: [],
  templateUrl: './listar-estado-orden.component.html',
  styleUrl: './listar-estado-orden.component.css'
})
export class ListarEstadoOrdenComponent {

}

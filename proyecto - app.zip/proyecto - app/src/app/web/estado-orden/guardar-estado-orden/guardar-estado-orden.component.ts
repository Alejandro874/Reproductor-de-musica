import { Component } from '@angular/core';

@Component({
  selector: 'app-guardar-estado-orden',
  imports: [],
  templateUrl: './guardar-estado-orden.component.html',
  styleUrl: './guardar-estado-orden.component.css'
})
export class GuardarEstadoOrdenComponent {

}

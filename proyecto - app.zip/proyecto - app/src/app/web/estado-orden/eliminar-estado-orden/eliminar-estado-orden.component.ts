import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-estado-orden',
  imports: [],
  templateUrl: './eliminar-estado-orden.component.html',
  styleUrl: './eliminar-estado-orden.component.css'
})
export class EliminarEstadoOrdenComponent {

}

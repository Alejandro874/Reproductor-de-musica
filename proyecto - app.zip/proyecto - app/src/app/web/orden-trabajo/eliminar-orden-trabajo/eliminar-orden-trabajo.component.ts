import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-orden-trabajo',
  imports: [],
  templateUrl: './eliminar-orden-trabajo.component.html',
  styleUrl: './eliminar-orden-trabajo.component.css'
})
export class EliminarOrdenTrabajoComponent {

}

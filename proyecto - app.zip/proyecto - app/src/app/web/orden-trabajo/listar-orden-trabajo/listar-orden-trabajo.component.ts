import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-orden-trabajo',
  imports: [],
  templateUrl: './listar-orden-trabajo.component.html',
  styleUrl: './listar-orden-trabajo.component.css'
})
export class ListarOrdenTrabajoComponent {

}

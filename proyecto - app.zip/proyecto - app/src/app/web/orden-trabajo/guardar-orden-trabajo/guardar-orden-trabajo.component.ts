import { Component } from '@angular/core';

@Component({
  selector: 'app-guardar-orden-trabajo',
  imports: [],
  templateUrl: './guardar-orden-trabajo.component.html',
  styleUrl: './guardar-orden-trabajo.component.css'
})
export class GuardarOrdenTrabajoComponent {

}

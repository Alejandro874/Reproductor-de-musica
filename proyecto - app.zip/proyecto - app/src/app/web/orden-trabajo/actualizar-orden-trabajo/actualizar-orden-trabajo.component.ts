import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-orden-trabajo',
  imports: [],
  templateUrl: './actualizar-orden-trabajo.component.html',
  styleUrl: './actualizar-orden-trabajo.component.css'
})
export class ActualizarOrdenTrabajoComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-tarea',
  imports: [],
  templateUrl: './actualizar-tarea.component.html',
  styleUrl: './actualizar-tarea.component.css'
})
export class ActualizarTareaComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-tarea',
  imports: [],
  templateUrl: './listar-tarea.component.html',
  styleUrl: './listar-tarea.component.css'
})
export class ListarTareaComponent {

}

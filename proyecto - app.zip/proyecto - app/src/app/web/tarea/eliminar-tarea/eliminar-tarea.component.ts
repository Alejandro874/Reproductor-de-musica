import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-tarea',
  imports: [],
  templateUrl: './eliminar-tarea.component.html',
  styleUrl: './eliminar-tarea.component.css'
})
export class EliminarTareaComponent {

}

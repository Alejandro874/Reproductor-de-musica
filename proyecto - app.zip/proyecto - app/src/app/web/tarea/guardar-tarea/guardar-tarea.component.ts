import { Component } from '@angular/core';

@Component({
  selector: 'app-guardar-tarea',
  imports: [],
  templateUrl: './guardar-tarea.component.html',
  styleUrl: './guardar-tarea.component.css'
})
export class GuardarTareaComponent {

}

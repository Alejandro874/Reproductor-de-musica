import { Component } from '@angular/core';

@Component({
  selector: 'app-estado-tarea',
  imports: [],
  templateUrl: './estado-tarea.component.html',
  styleUrl: './estado-tarea.component.css'
})
export class EstadoTareaComponent {

}

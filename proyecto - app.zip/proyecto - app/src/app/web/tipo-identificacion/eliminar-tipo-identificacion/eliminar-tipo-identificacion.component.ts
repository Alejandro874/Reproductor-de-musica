import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-tipo-identificacion',
  imports: [],
  templateUrl: './eliminar-tipo-identificacion.component.html',
  styleUrl: './eliminar-tipo-identificacion.component.css'
})
export class EliminarTipoIdentificacionComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-tipo-identificacion',
  imports: [],
  templateUrl: './actualizar-tipo-identificacion.component.html',
  styleUrl: './actualizar-tipo-identificacion.component.css'
})
export class ActualizarTipoIdentificacionComponent {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-listar-tipo-identificacion',
  imports: [],
  templateUrl: './listar-tipo-identificacion.component.html',
  styleUrl: './listar-tipo-identificacion.component.css'
})
export class ListarTipoIdentificacionComponent {

}

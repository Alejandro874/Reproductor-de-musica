import { Component } from '@angular/core';

@Component({
  selector: 'app-guardar-tipo-identificacion',
  imports: [],
  templateUrl: './guardar-tipo-identificacion.component.html',
  styleUrl: './guardar-tipo-identificacion.component.css'
})
export class GuardarTipoIdentificacionComponent {

}

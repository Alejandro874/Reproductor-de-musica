
export interface TipoIdentificacion{
    id_tipo_identificacion: number;
    nombre: string;
}
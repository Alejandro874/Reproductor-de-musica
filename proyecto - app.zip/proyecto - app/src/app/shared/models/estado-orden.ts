
export interface EstadoOrden{
    id_estado_orden: number;
    nombre: string;
}